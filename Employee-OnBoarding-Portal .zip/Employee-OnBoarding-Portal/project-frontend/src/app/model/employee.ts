export class Employee {
  employeeId: number;
  firstName: string;
  lastName: string;
  email: string;
  mobileNo: number;
  gender: string;
  address: string;
  nationality: string;
}
