import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  baseUrl = 'http://localhost:8185/myapp/employees';

  constructor(private http: HttpClient) {}
  getEmployees() {
    return this.http.get<Employee[]>(this.baseUrl);
  }

  createEmployee(employee: Employee) {
    return this.http.post<Employee>(this.baseUrl, employee);
  }

  deleteEmployee(employeeId: Number) {
    return this.http.delete(this.baseUrl + '/' + employeeId);
  }

  getEmployee(employeeId: number) {
    return this.http.get<Employee>(this.baseUrl + '/' + employeeId);
  }

  updateEmployee(employee: Employee) {
    return this.http.put(this.baseUrl, employee);
  }
}
