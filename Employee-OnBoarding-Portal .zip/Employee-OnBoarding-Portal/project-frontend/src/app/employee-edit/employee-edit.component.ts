import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { Employee } from '../model/employee';
import { EmployeeService } from '../services/employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employee-edit',
  templateUrl: './employee-edit.component.html',
  styleUrl: './employee-edit.component.css',
})
export class EmployeeEditComponent {
  employeeFormgroup: FormGroup;
  employee: Employee = new Employee();
  employeeFormGroup: any;
  constructor(
    private formBuilder: FormBuilder,
    private employeeService: EmployeeService,
    private router: Router,
    private activatedRout: ActivatedRoute
  ) {}
  ngOnInit() {
    this.employeeFormGroup = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      lastName: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      email: ['', [Validators.required, Validators.email]],
      mobileNo: [
        '',
        [Validators.required, Validators.pattern('[6-9][0-9]{9}')],
      ],
      gender: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      nationality: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      address: ['', [Validators.required]],
    });

    let id = this.activatedRout.snapshot.params['id'];

    this.employeeService.getEmployee(id).subscribe((data) => {
      this.employee = data;
    });
  }

  editEmployee() {
    if (confirm('Are you sure to update this employeee')) {
      this.employeeService.updateEmployee(this.employee).subscribe((data) => {
        alert('Employee Details updated Sucessfully!');
        this.router.navigateByUrl('/employee-list');
      });
    }
  }
}
