import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { EmployeeService } from '../services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrl: './employee-create.component.css',
})
export class EmployeeCreateComponent {
  employeeFormGroup: any;
  constructor(
    private formBuilder: FormBuilder,
    private employeeService: EmployeeService,
    private router: Router
  ) {}
  ngOnInit() {
    this.employeeFormGroup = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      lastName: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      email: ['', [Validators.required, Validators.email]],
      mobileNo: [
        '',
        [Validators.required, Validators.pattern('[6-9][0-9]{9}')],
      ],
      gender: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      nationality: ['', [Validators.required, Validators.pattern('[A-Za-z]+')]],
      address: ['', [Validators.required]],
    });
  }
  addEmployee() {
    if (this.employeeFormGroup.valid) {
      this.employeeService
        .createEmployee(this.employeeFormGroup.value)
        .subscribe((data) => {
          alert('New Employee Registeration Successful');
          this.router.navigateByUrl('/employee-list');
        });
      if (this.employeeFormGroup.invalid) {
        //  alert('Form is invalid');
        this.employeeFormGroup.markAllAsTouched();
      }
    }
  }
}
