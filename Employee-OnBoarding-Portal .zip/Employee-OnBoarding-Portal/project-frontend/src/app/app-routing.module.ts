import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { ReportusComponent } from './reportus/reportus.component';
import { HomeComponent } from './home/home.component';

import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeEditComponent } from './employee-edit/employee-edit.component';
import { EmployeeCreateComponent } from './employee-create/employee-create.component';
import { LoginformComponent } from './loginform/loginform.component';

const routes: Routes = [
  { path: '', component: HomeComponent,title:'Home' },
  { path: 'about-us', component: AboutusComponent,title:'AboutUs' },
  { path: 'contact-us', component: ContactusComponent,title:'ContactUs' },
  { path: 'report-us', component: ReportusComponent,title:'ReportUs' },
  { path: 'employee-create', component: EmployeeCreateComponent,title:'Create Employee' },
  { path: 'employee-list', component: EmployeeListComponent,title:'Employee List'},
  { path: 'edit/:id', component: EmployeeEditComponent,title:'Edit Employee'},
  { path: 'log-in', component: LoginformComponent,title:'Employee Login'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
