import { Component } from '@angular/core';
import { Employee } from '../model/employee';
import { EmployeeService } from '../services/employee.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css',
})
export class EmployeeListComponent {
  employees: Employee[] = [];

  constructor(
    private employeeService: EmployeeService,
    private router: Router
  ) {}

  ngOnInit() {
    this.getAllEmployees();
  }

  getAllEmployees() {
    this.employeeService.getEmployees().subscribe((data) => {
      alert(data);
      this.employees = data;
    });
  }

  removeEmployee(employeeId: number) {
    if (confirm('Are you sure delete this Employee?')) {
      this.employeeService.deleteEmployee(employeeId).subscribe((data) => {
        alert('Employee Scucessfully Deleted');
        this.getAllEmployees();
      });
    }
  }
  showEdit(id: number) {
    this.router.navigate(['edit', id]);
  }
}
