import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportusComponent } from './reportus.component';

describe('ReportusComponent', () => {
  let component: ReportusComponent;
  let fixture: ComponentFixture<ReportusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ReportusComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ReportusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
