import { Component } from '@angular/core';

@Component({
  selector: 'app-reportus',
  templateUrl: './reportus.component.html',
  styleUrl: './reportus.component.css'
})
export class ReportusComponent {

}
