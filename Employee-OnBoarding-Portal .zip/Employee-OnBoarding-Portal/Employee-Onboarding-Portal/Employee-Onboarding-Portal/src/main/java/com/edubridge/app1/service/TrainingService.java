package com.edubridge.app1.service;

import com.edubridge.app1.model.Training;
import com.edubridge.app1.repo.TrainingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TrainingService {
    @Autowired
    private TrainingRepository trainingRepository;

    public Training saveTraining(Training training) {
        return trainingRepository.save(training);
    }

    public Optional<Training> getTrainingById(Integer id) {
        return trainingRepository.findById(id);
    }

    public List<Training> getAllTrainings() {
        return trainingRepository.findAll();
    }

    public void deleteTraining(Integer id) {
        trainingRepository.deleteById(id);
    }

    public Training updateTraining(Integer id, Training training) {
        Optional<Training> optionalTraining = trainingRepository.findById(id);
        if (optionalTraining.isPresent()) {
            Training existingTraining = optionalTraining.get();
            // Update existingTraining with training's fields
            existingTraining.setTrainingName(training.getTrainingName());
            existingTraining.setDescription(training.getDescription());
            existingTraining.setDuration(training.getDuration());
            return trainingRepository.save(existingTraining);
        } else {
            return null; // Handle error or throw exception
        }
    }

    // Other methods as needed
}
