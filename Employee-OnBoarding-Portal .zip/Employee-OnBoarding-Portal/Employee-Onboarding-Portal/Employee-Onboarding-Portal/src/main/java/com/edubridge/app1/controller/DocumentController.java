package com.edubridge.app1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edubridge.app1.model.Document;
import com.edubridge.app1.service.DocumentService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/documents")
public class DocumentController {
    @Autowired
    private DocumentService documentService;

    @GetMapping("/all")
    public List<Document> getAllDocuments() {
        return documentService.getAllDocuments();
    }

    @GetMapping("/{documentId}")
    public ResponseEntity<Document> getDocumentById(@PathVariable("documentId") Integer documentId) {
        Document document = documentService.getDocumentById(documentId);
        if (document != null) {
            return ResponseEntity.ok(document);
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/create")
    public ResponseEntity<Document> createDocument(@RequestBody Document document) {
        Document newDocument = documentService.createDocument(document);
        return ResponseEntity.ok(newDocument);
    }

    @PutMapping("/update/{documentId}")
    public ResponseEntity<Document> updateDocument(@PathVariable("documentId") Integer documentId, @RequestBody Document updatedDocument) {
        Document document = documentService.updateDocument(documentId, updatedDocument);
        if (document != null) {
            return ResponseEntity.ok(document);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delete/{documentId}")
    public ResponseEntity<Void> deleteDocument(@PathVariable("documentId") Integer documentId) {
        documentService.deleteDocumentById(documentId);
        return ResponseEntity.noContent().build();
    }
}
