package com.edubridge.app1.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer employeeId;
	private String firstName;
	private String lastName;
	private String email;
	private long mobileNo;
	private String gender;
	private String address;
	private String nationality;
	
	/*
	@ManyToOne
	@JoinColumn(name = "department_id")
	private Department department;
	
	@ManyToOne
	@JoinColumn(name = "job_role_id")
	private JobRole jobRole;
	
	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    private List<Training> trainings;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL)
    private List<Document> documents;
*/	
}