package com.edubridge.app1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeOnboardingPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeOnboardingPortalApplication.class, args);
	}

}
