package com.edubridge.app1.controller;

import com.edubridge.app1.model.JobRole;
import com.edubridge.app1.service.JobRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/jobRoles")
public class JobRoleController {
    @Autowired
    private JobRoleService jobRoleService;

    @PostMapping
    public ResponseEntity<JobRole> addJobRole(@RequestBody JobRole jobRole) {
        JobRole savedJobRole = jobRoleService.saveJobRole(jobRole);
        return new ResponseEntity<>(savedJobRole, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<JobRole>> getAllJobRoles() {
        List<JobRole> jobRoles = jobRoleService.getAllJobRoles();
        return new ResponseEntity<>(jobRoles, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobRole> getJobRoleById(@PathVariable Integer id) {
        Optional<JobRole> jobRole = jobRoleService.getJobRoleById(id);
        return jobRole.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<JobRole> updateJobRole(@PathVariable Integer id, @RequestBody JobRole jobRole) {
        JobRole updatedJobRole = jobRoleService.updateJobRole(id, jobRole);
        return updatedJobRole != null ?
                new ResponseEntity<>(updatedJobRole, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJobRole(@PathVariable Integer id) {
        jobRoleService.deleteJobRole(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
