package com.edubridge.app1.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "EmployeeJobRole")
public class JobRole {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer jobRoleId;
	private String roleName;
	private String responsibilities;
	private double salary;
	private String experienceLevel;
	/*
	@OneToMany(mappedBy = "jobRole")
	private List<Employee> employee;
*/	
}
