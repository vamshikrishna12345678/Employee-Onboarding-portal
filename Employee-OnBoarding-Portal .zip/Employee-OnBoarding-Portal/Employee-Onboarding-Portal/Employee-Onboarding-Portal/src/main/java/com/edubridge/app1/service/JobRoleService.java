package com.edubridge.app1.service;

import com.edubridge.app1.model.JobRole;
import com.edubridge.app1.repo.JobRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class JobRoleService {
    @Autowired
    private JobRoleRepository jobRoleRepository;

    public JobRole saveJobRole(JobRole jobRole) {
        return jobRoleRepository.save(jobRole);
    }

    public Optional<JobRole> getJobRoleById(Integer id) {
        return jobRoleRepository.findById(id);
    }

    public List<JobRole> getAllJobRoles() {
        return jobRoleRepository.findAll();
    }

    public void deleteJobRole(Integer id) {
        jobRoleRepository.deleteById(id);
    }

    public JobRole updateJobRole(Integer id, JobRole jobRole) {
        Optional<JobRole> optionalJobRole = jobRoleRepository.findById(id);
        if (optionalJobRole.isPresent()) {
            JobRole existingJobRole = optionalJobRole.get();
            // Update existingJobRole with jobRole's fields
            existingJobRole.setRoleName(jobRole.getRoleName());
            existingJobRole.setResponsibilities(jobRole.getResponsibilities());
            existingJobRole.setSalary(jobRole.getSalary());
            existingJobRole.setExperienceLevel(jobRole.getExperienceLevel());
            return jobRoleRepository.save(existingJobRole);
        } else {
            return null; // Handle error or throw exception
        }
    }

    // Other methods as needed
}
