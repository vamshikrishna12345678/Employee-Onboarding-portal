package com.edubridge.app1.service;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.edubridge.app1.model.Document;

import com.edubridge.app1.repo.DocumentRepository;


@Service
public class DocumentService {
    @Autowired
    private DocumentRepository documentRepository;

    public List<Document> getAllDocuments() {
        return documentRepository.findAll();
    }

    public Document getDocumentById(Integer documentId) {
        return documentRepository.findById(documentId).orElse(null);
    }

    public Document createDocument(Document document) {
        return documentRepository.save(document);
    }

    public Document updateDocument(Integer documentId, Document updatedDocument) {
        Document document = getDocumentById(documentId);
        if (document != null) {
            document.setDocumentName(updatedDocument.getDocumentName());
            document.setDocumentType(updatedDocument.getDocumentType());
            document.setDocumentUrl(updatedDocument.getDocumentUrl());
            //document.setEmployee(updatedDocument.getEmployee());
            return documentRepository.save(document);
        }
        return null;
    }

    public void deleteDocumentById(Integer documentId) {
        documentRepository.deleteById(documentId);
    }
   
    
    
}