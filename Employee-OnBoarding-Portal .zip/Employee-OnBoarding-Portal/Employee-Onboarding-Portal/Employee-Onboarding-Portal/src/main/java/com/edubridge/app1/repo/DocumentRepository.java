package com.edubridge.app1.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edubridge.app1.model.Document;

public interface DocumentRepository extends JpaRepository<Document, Integer> {
}
