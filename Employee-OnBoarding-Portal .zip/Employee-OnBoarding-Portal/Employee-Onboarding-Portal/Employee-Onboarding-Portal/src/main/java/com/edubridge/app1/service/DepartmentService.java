package com.edubridge.app1.service;

import com.edubridge.app1.model.Department;
import com.edubridge.app1.repo.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {
    @Autowired
    private DepartmentRepository departmentRepository;

    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    public Optional<Department> getDepartmentById(Integer id) {
        return departmentRepository.findById(id);
    }

    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    public void deleteDepartment(Integer id) {
        departmentRepository.deleteById(id);
    }

    public Department updateDepartment(Integer id, Department department) {
        Optional<Department> optionalDepartment = departmentRepository.findById(id);
        if (optionalDepartment.isPresent()) {
            Department existingDepartment = optionalDepartment.get();
            // Update existingDepartment with department's fields
            existingDepartment.setDepartmentName(department.getDepartmentName());
            existingDepartment.setLocation(department.getLocation());
            return departmentRepository.save(existingDepartment);
        } else {
            return null; // Handle error or throw exception
        }
    }

    // Other methods as needed
}
