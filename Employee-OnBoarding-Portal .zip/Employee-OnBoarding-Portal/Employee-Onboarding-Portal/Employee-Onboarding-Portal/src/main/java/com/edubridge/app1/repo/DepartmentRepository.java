package com.edubridge.app1.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.edubridge.app1.model.Department;

public interface DepartmentRepository extends JpaRepository<Department, Integer> {

}
